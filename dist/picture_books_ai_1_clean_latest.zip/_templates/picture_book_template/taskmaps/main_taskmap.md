# Main Taskmap

## Objectives
- Define the story’s learning and narrative goals

## Constraints
- 32 pages, each with narrative, code, and illustration

## Beat Plan
- Each `pageNN.md` is a micro-task
- Link each page backward/forward for continuity

## Open Questions
- What is the core puzzle or learning arc?
- How do illustration and code tasks reinforce the story?
