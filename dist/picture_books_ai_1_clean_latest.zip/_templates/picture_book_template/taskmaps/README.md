# Taskmaps for AI Player (Book)

Purpose: Planning zone for the AI player (this book)

Conventions: Each page is a narrative + code + illustration milestone

Editing tips: Keep pages short, use placeholders, commit often
