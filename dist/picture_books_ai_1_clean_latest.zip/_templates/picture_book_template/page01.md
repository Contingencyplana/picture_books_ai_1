{{BOOK_TITLE}} — Page {{PAGE_NUMBER}}
She came from where the last clue hummed softly behind her.
Ahead, a small decision flickered, asking to be tried next.
// Code Task: {{BOOK_ID}}.page{{PAGE_NUMBER}}() → TODO
[Illustration: A motif that matches {{BOOK_TITLE}} at page {{PAGE_NUMBER}}.]
